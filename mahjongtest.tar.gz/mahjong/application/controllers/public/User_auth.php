<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');	

class User_Auth extends CI_Controller {
	function __construct() {
		parent::__construct();

		$this->load->helper("url");
		$this->load->library("session");
		$uid = $this->uri->segment(4);
		$uid = intval($uid);
		if ($uid == 0) {
			exit("404 Not Found");
		}
		$this->load->model("gm_model");
		$data = $this->gm_model->request("/GetToken", array("UId"=>$uid));

		$token = $this->uri->segment(5);
		if ( !$token || $token != $data->String) {
			exit("无效的会话");
		}

		$this->load->model("agent_model");
	}

	// 代理入口
	function agent($uid=0, $token=null) {
		$uid = intval($uid);
		$user = $this->user_model->get_user_info($uid);
		if ( !$user ) {
			exit('404 Not Found');	
		}
		$this->session->set_userdata("agent_uid", $uid);
		redirect("/public/agent/add_card");
	}
}

/* End of file welcome.php */
/* Location: ./share/application/controllers/welcome.php */
