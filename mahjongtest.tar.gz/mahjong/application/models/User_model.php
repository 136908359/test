<?php
class User_Model extends CI_Model {
	function __construct() {
		parent::__construct();
		$this->load->database();
		$this->mahjong = $this->load->database('mahjong',TRUE);
	}
	function get_user_info($uid) {
		$user = $this->mahjong->query("select * from user_info where uid=?",array($uid))->row_array();	
		if ( $user ) {
			$uid = $user['uid'];
			$row = $this->db->query("select sum(rmb) as total from charge_order where buy_uid=? and result=3",array( $uid ))->row_array();	
			$user['total_pay'] = $row['total'];
		}
		return $user;
	}
}
