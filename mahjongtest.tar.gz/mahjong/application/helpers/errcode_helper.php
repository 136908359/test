<?php
function err_string($msg, $params=array()) {
	$data = array("Msg"=>$msg);
	$data = array_merge($data, (array)$params);
	return json_encode($data,JSON_UNESCAPED_UNICODE);
}
?>
