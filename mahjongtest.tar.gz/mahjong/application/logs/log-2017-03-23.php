<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2017-03-23 10:15:46 --> Severity: Warning  --> Missing argument 4 for Plate::create_player(), called in D:\web\mahjong\system\core\CodeIgniter.php on line 359 and defined D:\web\mahjong\application\controllers\plate.php 26
