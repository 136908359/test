<?php
	$key = "123";
	$val = "123";
	$xml="<";
	echo $xml;
	$xml = $xml.$key."><![CDATA[".$val."]]></".$key.">";
	echo $xml;
?>
